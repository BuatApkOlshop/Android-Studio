---
title: "Tutorial"
excerpt: "Tutorial."
---
Fungsi & Petunjuk
[block:code]
{
  "codes": [
    {
      "code": "$http.post('/someUrl', data).success(successCallback);\nalert('test');\n$ touch {slug}.md\n $ rdme docs folder-of-your-markdown-files \\\n  --key=KaOD5ICbfKiUarBO80WQM81zn1de1Acm \\\n  --version=1.0",
      "language": "javascript"
    },
    {
      "code": " ---\ncategory: 5c77bfba723f950014c31d96\ntitle: Your page title goes here\n---\n\nThis is where your body content goes.\n",
      "language": "markdown"
    },
    {
      "code": "$ npm install rdme@3 -g",
      "language": "shell"
    }
  ]
}
[/block]
<<CALING>> :calling: {v1.1}

---

[M A S U K](https://dash.readme.io/api/v1)