---
title: "DAFTAR"
excerpt: "This page will help you get started with LOG IN."
---
This is where you show your users how to set it up. You can use code samples, like this:
[block:code]
{
  "codes": [
    {
      "code": "$http.post('/someUrl', data).success(successCallback);\n\nalert('test');\n\nexports.jwt = function(user) {\n  // config.jwt_secret is provided by readme and used to sign the request\n  const jwt = sign(user, config.jwt_secret);\n  return \"https://yourproject.readme.io?auth_token=\" + jwt;\n};",
      "language": "javascript"
    },
    {
      "code": "const sign = require('jsonwebtoken').sign",
      "language": "shell"
    },
    {
      "code": " https://dash.readme.io/api/v1 -X GET -u KaOD5ICbfKiUarBO80WQM81zn1de1Acm:",
      "language": "http"
    },
    {
      "code": "**W E L C O M E     T O     M A R K E T P L A C E **\n\n---\n\n**SIG IN APP**\n\n[D A F T A R](https://dash.readme.io/api/v1 -X GET -u KaOD5ICbfKiUarBO80WQM81zn1de1Acm:)",
      "language": "markdown"
    }
  ]
}
[/block]