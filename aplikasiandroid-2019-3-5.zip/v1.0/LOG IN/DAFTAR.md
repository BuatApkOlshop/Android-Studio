---
title: "DAFTAR"
excerpt: "This page will help you get started with LOG IN."
---
*Apakah Ini membantu...!!!*

---

[SUKA](bbusines77@gmail.com) :+1: 

[TIDAK](bbusines77@gmail.com) :-1: 
[block:code]
{
  "codes": [
    {
      "code": "$http.post('/someUrl', data).success(successCallback);\n\nalert('test');\n\nexports.jwt = function(user) {\n  // config.jwt_secret is provided by readme and used to sign the request\n  const jwt = sign(user, config.jwt_secret);\n  return \"https://yourproject.readme.io?auth_token=\" + jwt;\n};",
      "language": "javascript"
    },
    {
      "code": "const sign = require('jsonwebtoken').sign",
      "language": "shell"
    },
    {
      "code": " $ https://dash.readme.io/api/v1 -X GET -u KaOD5ICbfKiUarBO80WQM81zn1de1Acm:\n  $ http://aplikasiandroid.readme.io/v1.0/reference/reference-getting-started-1?showHidden=a6668#keluar",
      "language": "http"
    },
    {
      "code": "**W E L C O M E     T O     M A R K E T P L A C E **\n\n---\n\n**SIG IN APP**\n\n[D A F T A R](https://dash.readme.io/api/v1 -X GET -u KaOD5ICbfKiUarBO80WQM81zn1de1Acm:)\n\n[ K E L U A R]( http://aplikasiandroid.readme.io/v1.0/reference/reference-getting-started-1?showHidden=a6668#keluar)",
      "language": "markdown"
    },
    {
      "code": "#sampel jwt\n\n{\n    \"key\": \"Instal-app\",\n    \"name\": \"Aplikasi\",\n    \"description\": \"An example app for Android\",\n    \"vendor\": {\n        \"name\": \"Blog-Apk\",\n        \"url\": \"https://bitbucket.org/Aplikasi/0e632dd\"\n    },\n",
      "language": "javascript"
    },
    {
      "code": "#jwt\n\"baseUrl\": \"https://bitbucket.org/Aplukasi\",\n    \"authentication\": {\n        \"type\": \"jwt\"\n    },\n",
      "language": "http"
    },
    {
      "code": "#jwt\n\n\"lifecycle\": {\n        \"installed\": \"/installed\",\n        \"uninstalled\": \"/uninstalled\"\n    },",
      "language": "shell"
    },
    {
      "code": "{\n    \"key\": \"aplikasi\",\n    \"name\": \"readme.md\",\n    \"description\": \"An example app for Android\",\n    \"vendor\": {\n        \"name\": \"readme.md\",\n        \"url\": \" https://bitbucket.org/androidorg/aplikasi/ },\n    \"baseUrl\": \"https://bitbucket.org/aplikasi\",\n    \"authentication\": {\n        \"type\": \"jwt\"\n    },\n    \"lifecycle\": {\n        \"installed\": \"/installed\",\n        \"uninstalled\": \"/uninstalled\"\n    },\n    \"modules\": {\n        \"oauthConsumer\": {\n            \"clientId\": \"{{consumerKey}}\"\n        },\n        \"webhooks\": [\n            {\n                \"event\": \"*\",\n                \"url\": \"/webhook\"\n            }\n        ],\n        \"webItems\": [\n            {\n                \"url\": \"http://bitbucket.org/aplikasi?repoPath={repo_path}\",\n                \"name\": {\n                    \"value\": \"Aplikasi Web Item\"\n                },\n                \"location\": \"org.bitbucket.repository.navigation\",\n                \"key\": readme.md-web-item\",\n                \"params\": {\n                    \"auiIcon\": \"aui-iconfont-link\"\n                }\n            }\n        ],\n        \"repoPages\": [\n            {\n                \"url\": \"/connect-bbusines77?repoPath={repo_path}\",\n                \"name\": {\n                    \"value\": \"readme.md Page\"\n                },\n                \"location\": \"org.bitbucket.repository.navigation\",\n                \"key\": \"readme.md-repo-page\",\n                \"params\": {\n                    \"auiIcon\": \"aui-iconfont-doc\"\n                }\n            }\n        ],\n        \"webPanels\": [\n            {\n                \"url\": \"/connect-bbusines77?repoPath={repo_path}\",\n                \"name\": {\n                    \"value\": \"readme.md Web Panel\"\n                },\n                \"location\": \"org.bitbucket.repository.overview.informationPanel\",\n                \"key\": \"aplikasi-web-panel\"\n            }\n        ]\n    },\n    \"scopes\": [\"account\", \"repository\"],\n    \"contexts\": [\"account\"]\n}\n\n\n\n",
      "language": "yaml"
    }
  ]
}
[/block]