---
title: "Keluar"
excerpt: ""
---
[APPS](http://aplikasiandroid.readme.io/v1.0/reference/reference-getting-started-1?showHidden=a6668#keluar)

---
category: 5c7c0d88d43951005d1644c3
parentDoc: 5c7c0d88d43951005d1644c4
title: Your page title goes here
---
[block:code]
{
  "codes": [
    {
      "code": "alert(test('123')); // should return '123!'  \n$ rdme docs folder-of-your-markdown-files \\\n  --key=KaOD5ICbfKiUarBO80WQM81zn1de1Acm \\\n  --version=1.0",
      "language": "javascript"
    },
    {
      "code": " $ npm install rdme@3 -g\n $ rdme docs folder-of-your-markdown-files \\\n  --key=KaOD5ICbfKiUarBO80WQM81zn1de1Acm \\\n  --version=1.0\n",
      "language": "shell"
    }
  ]
}
[/block]