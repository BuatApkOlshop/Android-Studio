---
title: "PRODUK POST"
excerpt: "selamat datang di marketplace"
---
Di sini kami sudah menyediakan tutorial yang bisa membantu anda dalam mengakses Marketplace berikut ulasannya..
[block:code]
{
  "codes": [
    {
      "code": "const readme = require('readmeio');\napp.use(readme.metrics('KaOD5ICbfKiUarBO80WQM81zn1de1Acm', req => ({\n    id: req.project._id\nChange this to a unique identifier\n, // a unique id associated with the project\n    label: req.project.name, // a human-readable name for the project\n    email: req.project.user.email, // email associated with this project\n})));",
      "language": "javascript"
    },
    {
      "code": "$npm install readmeio --save",
      "language": "shell"
    },
    {
      "code": "https://readme.io/api/v1 -X GET -u KaOD5ICbfKiUarBO80WQM81zn1de1Acm:",
      "language": "http"
    },
    {
      "code": "t$ npm install rdme@3 -g\n$ touch {slug}.md\n $ rdme docs folder-of-your-markdown-files \\\n  --key=KaOD5ICbfKiUarBO80WQM81zn1de1Acm \\\n  --version=1.0",
      "language": "shell"
    },
    {
      "code": " ---\ncategory: 5c77bfba723f950014c31d96\ntitle: Your page title goes here\n---\n\nThis is where your body content goes.\n",
      "language": "json"
    },
    {
      "code": "const sign = require('jsonwebtoken').sign;\n\nexports.jwt = function(user) {\n  // User being logged into ReadMe\n  const user = {\n    name: 'bbusines77',\n    email: 'bbusines77@gmail.com',\n    apiKey: ' A63nb9Ab1BPm',\n  };",
      "language": "yaml"
    },
    {
      "code": "<!DOCTYPE html>\n<html>\n    <head>\n        <title>Dialog Confirm</title>\n    </head>\n    <body>\n    <script>\n        var yakin = confirm(\"Apakah kamu yakin akan mengunjungi Aplikasi Android?\");\n\n        if (yakin) {\n            window.location = \" https://dash.readme.io/api/v1\";\n        } else {\n            document.write(\"Baiklah, tetap di sini saja ya :)\");\n        }\n    </script>\n    </body>\n</html>",
      "language": "go"
    }
  ]
}
[/block]
TAMBAH PRODUK ANDA DI SINI

---

**KATEGORI**

---

<<ITEM  PRODUK>>  :kimono: 


   - [+ ITEM](http://aplikasiandroid.readme.io/v1.0/reference/item-pakaian?showHidden=a6668#undefined)


---

<<ITEM ACESORIES>> :watch:    

-  [+ ITEM]( http://aplikasiandroid.readme.io/v1.0/reference/item-acesories?showHidden=a6668#undefined)

---

<<ITEM PERAWATAN>> :haircut:    

-  [+ ITEM](http://aplikasiandroid.readme.io/v1.0/reference/salon-rambut?showHidden=a6668#undefined)

---

<<ITEM BENGKEL>> :taxi: 

- [+ ITEM]( http://aplikasiandroid.readme.io/v1.0/reference/bengkel-motor?showHidden=a6668#undefined)

---

<<ITEM MAKANAN>> :ice-cream:

- [+ ITEM]( http://aplikasiandroid.readme.io/v1.0/reference/item-kuliner?showHidden=a6668#undefined)


---

<<ITEM ELECTRONIK>> :video-camera:  :vhs: 

---

<<ITEM BAYI>> :baby-bottle: 

---

Selamat Menjelajahi di marketplace