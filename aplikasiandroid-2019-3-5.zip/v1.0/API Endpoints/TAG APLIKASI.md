---
title: "TAG APLIKASI"
excerpt: "This page will help you get started with ."
---
This is where you show your users how to set it up. You can use code samples, like this:
[block:code]
{
  "codes": [
    {
      "code": "$http.post('/someUrl', data).success(successCallback);\n\nalert('test');https://dash.readme.io/project/aplikasiandroid/v1.0/refs/reference-getting-started-3",
      "language": "javascript"
    },
    {
      "code": "#TAG VIDEO SCR\n---\n>scr adalah tag atau acrip yang bisa menghubungkan elemen video yang kita upload atau masukan\n\n**CONTOH TAG**\n\n---\n\n<video src=\"https://drive.google.com/file/d/19WNYGbydDPwk2y_wpAvsOJz2Q7PaQlR4/view?usp=drivesdk \" width=400 controls>\n</video>",
      "language": "markdown"
    },
    {
      "code": "",
      "language": "text"
    },
    {
      "code": "**TAG URL**\n\nCONTOH : [EXAMPEL](Www.exampel.com)\n\nEXAMPEL : [EXAMPEL APLIKASI](https://readme.io/aplikasiandroid)",
      "language": "json"
    }
  ]
}
[/block]
Try dragging a block from the right to see how easy it is to add more content!